/**
 * 
 */
/**
 * @author ASUS
 *
 */
module ChallengeString {
}
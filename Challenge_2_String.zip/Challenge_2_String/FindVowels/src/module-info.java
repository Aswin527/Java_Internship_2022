/**
 * 
 */
/**
 * @author ASUS
 *
 */
module FindVowels {
}
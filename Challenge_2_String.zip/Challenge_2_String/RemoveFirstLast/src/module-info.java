/**
 * 
 */
/**
 * @author ASUS
 *
 */
module RemoveFirstLast {
}
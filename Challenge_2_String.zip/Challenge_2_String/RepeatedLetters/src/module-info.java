/**
 * 
 */
/**
 * @author ASUS
 *
 */
module RepeatedLetters {
}